using System;
using System.Threading.Tasks;
using Microsoft.Diagnostics.Tracing;
using Microsoft.Diagnostics.Tracing.Session;

namespace PrivacyMeter.Desktop.Services
{
    public sealed class EtwDnsListener : IDisposable
    {
        private TraceEventSession? _session;
        private Task? _task;
        private volatile bool _running;
        private static readonly Guid DnsClientProvider = new("1c95126e-7eea-49a9-a3fe-a378b03ddb4d");

        public event Action<DateTime,int,string>? OnDns; // ts, pid, domain

        public void Start()
        {
            if (_running) return;
            _running = true;
            var sessionName = "PM_DnsWpf_" + Guid.NewGuid().ToString("N");
            _session = new TraceEventSession(sessionName) { StopOnDispose = true };

            _task = Task.Run(() =>
            {
                using var source = new ETWTraceEventSource(_session!.SessionName, TraceEventSourceType.Session);
                var parser = new DynamicTraceEventParser(source);
                parser.AddDynamicProvider(DnsClientProvider, TraceEventLevel.Informational);

                parser.All += (TraceEvent e) =>
                {
                    if (!_running) return;
                    var qname = (e.PayloadByName("QueryName") as string)
                                ?? (e.PayloadByName("HostName") as string) ?? "";
                    if (string.IsNullOrWhiteSpace(qname)) return;
                    OnDns?.Invoke(DateTime.Now, e.ProcessID, qname.ToLowerInvariant());
                };

                _session.EnableProvider(DnsClientProvider);
                try { source.Process(); } catch { /* swallow on dispose */ }
            });
        }

        public void Stop()
        {
            _running = false;
            _session?.Dispose();
            _task?.Wait(500);
        }

        public void Dispose() => Stop();
    }
}
