using System.Windows;

namespace PrivacyMeter.Desktop
{
    public partial class App : Application { }
}
